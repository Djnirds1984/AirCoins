# Changelog

All notable changes to AirCoins are documented in this file.

---

## v1.16.8 — Anti-Hotspot: Pure TTL=1 (No Client Bypass)

**Release date:** August 2026

### Changed
- **Anti-hotspot now applies pure TTL=1 to the client device** — no per-MAC bypass.
- TTL=1 is set on ALL packets from the portal interface in mangle PREROUTING.
- The client device gets TTL=1 → if they enable hotspot, tethered devices cannot reach the internet.
- Removed AddTTL1Bypass/RemoveTTL1Bypass functions (no longer needed).
- Removed ifaceForClientMAC helper function.
- Updated admin panel hint text to clarify behavior.

---

## v1.16.4 — Anti-Hotspot: MikroTik-Style TTL=1 + Per-MAC RETURN

**Release date:** August 2026

### Changed
- **Anti-hotspot now uses MikroTik-style TTL=1 + per-MAC RETURN** — exactly like MikroTik hotspot server TTL=1.
- ALL packets from the portal interface get TTL set to 1 (die at first hop).
- The authorized client's MAC gets a RETURN rule in the mangle chain → bypasses TTL=1 → normal internet.
- Friends' packets (different MACs, no RETURN match) → TTL=1 → die at first hop → blocked.
- Uses mangle table PREROUTING hook, not filter table. Filter chain is unchanged.
- When you ping the gateway with anti-hotspot ON, the authorized client sees normal TTL (because of RETURN). Friends see TTL=1.

---

## v1.16.3 — Anti-Hotspot: Per-MAC Filtering (MikroTik-style 1:1)

**Release date:** August 2026

### Changed
- **Anti-hotspot now uses per-MAC filtering** instead of unreliable TTL-based detection. Only the authorized client's MAC address can forward traffic. Friends' devices (different MACs) are blocked — regardless of whether the phone decrements TTL or not.
- This is the same approach MikroTik uses for 1:1 hotspot connections.
- **How it works:** When anti-hotspot is ON, the catch-all ACCEPT is replaced with catch-all DROP. Only authorized clients (per-MAC ACCEPT rules added during auth) can forward. Tethered devices with different MACs are dropped.

---

## v1.16.2 — Fix: Anti-Hotspot No Longer Blocks Client

**Release date:** August 2026

### Fixed
- **Anti-hotspot now correctly blocks ONLY tethered devices** — Previous approach (TTL=1) blocked ALL packets from the portal including the paying client's own device. New approach DROPs packets with TTL≤63, which are the friends' packets (decremented by client's phone from 64→63). The client's own packets (TTL=64) pass through untouched.
- **How it works:** Most devices send TTL=64. When client enables hotspot, their phone acts as a router and decrements TTL by 1 on friends' packets (64→63). We DROP TTL≤63 at the portal — client (64) passes, friends (63) blocked.

---

## v1.16.1 — Fix: Captive Rules Fail When Anti-Hotspot Enabled

**Release date:** August 2026

### Fixed
- **Captive rules now work with anti-hotspot enabled** — Anti-hotspot TTL=1 rules are now applied directly by the Go API via iptables, instead of relying on the shell script. This fixes the issue where enabling anti-hotspot caused the Captive status to show "Fail" on devices with older script versions.
- **Backward compatibility** — The shell script is now always called with 3 args (action, iface, gateway), ensuring it works on all devices regardless of script version.

---

## v1.16.0 — Portal Servers CRUD + Anti-Hotspot (TTL=1)

**Release date:** August 2026

### Added
- **Anti-Hotspot (TTL=1 Hop Limit)** — New per-portal setting that forces IP TTL=1 on client packets, preventing tethering/hotspotting. When enabled, only the paying client's device gets internet access — their friends' devices cannot connect through them.
- **Portal Servers CRUD (Edit)** — Portal servers can now be edited after creation. Click the ✏️ button to modify IP, DHCP range, lease time, or anti-hotspot settings. Changes apply immediately to running portals.
- **Database migration 014** — Adds `anti_hotspot` column to `portal_servers` table

### Changed
- Portal config file format extended to 7 columns (backward compatible with 6-column format)
- Captive rules script (`aircoins-captive-rules`) accepts optional `anti_hotspot` parameter for TTL mangling via iptables mangle table

---

## v1.15.3 — Build Update

**Release date:** August 2026

### Changed
- **Version bump** — Build release v1.15.3

---

## v1.10.11 — Allow Admin Access When Locked

**Release date:** August 2026

### Fixed
- **Locked devices can now access License and Updater pages** — Previously, locked devices were completely blocked from the admin panel. Now users can access the License page (to purchase/activate) and the Updater page (to update software) even when locked.
- **Backend middleware** — Added `/api/admin/update/*` to the list of routes that bypass the license gate.
- **Frontend lockdown** — Updated `lockDownForLicense()` and `showSection()` to keep License and Updater nav items visible.

---

## v1.10.10 — WAN: Fix "Cannot find device eth0" on end0 Systems

**Release date:** August 2026

### Fixed
- **WAN interface detection now scans for end0, eth0, enp*, ens*, enx*** — Previously only used `ip route show default` which fails when there's no default route. Now falls back to scanning `/sys/class/net` for the first Ethernet-like interface that is UP.
- **Hardware fingerprint MAC detection** — Now scans for any Ethernet interface (end0, eth0, etc.) instead of hardcoded `eth0`.
- **Stored eth_interface fallback** — Only used as last resort, and now verifies the interface actually exists before returning it.

---

## v1.10.9 — WAN: Fix dhclient/dhcpcd Service Error

**Release date:** August 2026

### Fixed
- **No more "dhclient.service not found" error** — `applyDHCP()` now falls back to running the DHCP binary directly (`dhclient -v eth0`) when `systemctl restart` fails. No dummy service needed.
- **Static IP no longer depends on dhcpcd** — `applyStatic()` now uses `iproute2` commands directly (`ip addr add`, `ip route add`) instead of writing to `/etc/dhcpcd.conf` and restarting dhcpcd. Works on all modern Linux.
- **VLAN DHCP already uses direct request** — `applyVLANDHCP()` was already fixed in v1.10.2.

---

## v1.10.8 — Fix: Cloned SD Cards Now Get Fresh Trial

**Release date:** August 2026

### Fixed
- **Hardware fingerprint now detects cloned SD cards** — Added 3 new hardware ID sources: device tree serial (Allwinner SID), Ethernet MAC address, and auto-regeneration of `/etc/machine-id`. Previously, cloned SD cards had the same machine-id, so the system couldn't tell they were on a different board.
- **Auto-regenerate machine-id** — When the SD card is moved to a new board, the system detects the hardware change (via MAC address or SoC serial) and regenerates `/etc/machine-id` with a new unique ID. This triggers a fresh 7-day trial automatically.
- **Hardware stamp file** — New `/etc/machine-id.hardware-stamp` tracks which hardware the machine-id belongs to, so cloned cards are detected on first boot.

---

## v1.10.7 — Reset Sales Reports

**Release date:** August 2026

### Added
- **Reset Sales Reports button** — New section at the bottom of the Reports page with a "Reset All Sales Data" button. Deletes all daily stats, coin events, and session records. Includes double confirmation to prevent accidental resets.

---

## v1.10.6 — License: Auto-Reset Trial on Hardware Change

**Release date:** August 2026

### Changed
- **Hardware change = fresh 7-day trial** — When the SD card is cloned to a new SBC board, the system detects the new CPU serial and automatically starts a fresh 7-day trial. No more "locked" state from hardware mismatch.
- **Removed hardware mismatch lock** — The device no longer locks when the hardware ID changes. Instead, it treats the new board as a new device and starts a trial.
- **Heartbeat uses live hardware ID** — The Supabase heartbeat now reports the actual hardware ID of the current board.

### Business flow
1. Flash image to SD card → insert into new SBC board
2. System detects new CPU serial (hardware ID)
3. Automatic 7-day trial starts
4. Buyer purchases license → activates permanently
5. If trial expires without purchase → device locks (as expected)

---

## v1.10.5 — Updater Refactor: Version Cards & Rollback

**Release date:** August 2026

### Added
- **Version cards UI** — The updater now shows a card for each available version (up to 5), with individual Download and Install buttons per version.
- **Easy rollback** — Download and install any previous version directly from the updater. If a new version causes issues, roll back to a stable version with one click.
- **Auto-check on open** — The updater automatically checks for updates when you open the section. No more clicking "Check for Updates" manually.
- **Smooth UI** — No more blinking/flickering during update checks. Status badges show "Installed", "New", or "Older" for each version card.
- **Downloaded badge** — Already-downloaded versions show a blue "Downloaded" badge with an Install button.

---

## v1.10.4 — VLAN ISP IP Info & Internet Connectivity

**Release date:** August 2026

### Added
- **VLAN ISP Connection Info panel** — When in VLAN DHCP mode, a separate green panel shows the VLAN interface's IP, subnet, gateway, and DNS (e.g. `end0.500`). Makes it easy to verify the VLAN ISP is connected.
- **Internet connectivity check** — A status bar shows whether the device can actually reach the internet (pings 8.8.8.8). Green = connected, Red = no internet.
- **VLAN interface status** — Shows whether the VLAN interface is up/down with a helpful message if the ISP link is not active.

---

## v1.10.3 — WAN IP Info Display

**Release date:** August 2026

### Added
- **ISP Connection Info panel** — New card in WAN Settings showing the live IP address, subnet, gateway, and DNS obtained from the ISP. Includes interface status indicator (up/down). Refreshes automatically when you click the refresh button.

---

## v1.10.2 — VLAN WAN DHCP Client Auto-Detection

**Release date:** August 2026

### Fixed
- **VLAN WAN apply failed: "dhcpcd end0.X failed"** — The WAN handler hardcoded `dhcpcd` for obtaining DHCP on VLAN interfaces, but Armbian systems typically use `dhclient`, `udhcpc`, or NetworkManager. The system now auto-detects the available DHCP client (dhclient → dhcpcd → udhcpc → nmcli) and uses whichever is installed.
- **DHCP service restart also fixed** — Plain DHCP mode now restarts the correct DHCP client service instead of always trying `dhcpcd`.

---

## v1.10.1 — GPIO Multi-Pulse Coin Counting Fix

**Release date:** August 2026

### Fixed
- **Multi-peso coins only counted as 1 pulse** — The `handle_coin_pulse()` function in `gpio-coin-listener` was blocking for 150ms+ and then waiting for the pin to go HIGH after each pulse. This caused all subsequent pulses in a rapid train to be missed. A 10-peso coin (10 pulses) was read as a single 1-peso coin.
- **Debounce moved to callers** — The pin-wait logic is now handled by the polling loop and gpiomon loop (which need it for edge tracking), while `handle_coin_pulse()` returns immediately after a short 50ms electrical debounce. This allows every pulse in a multi-pulse coin to be detected.

---

## v1.10.0 — Bridge/VLAN Portal Management

**Release date:** August 2026

### Added
- **Network Bridges** — create and manage network bridges from the admin panel
- **Bridge Members** — manually add/remove VLAN interfaces as layer-2 bridge members
- **Portal on Bridge** — provision captive portals on bridge interfaces
- **Bridges UI** — new Bridges section in admin sidebar
- **Change Password** — new card on Settings page to change admin password
- **Permanent device tokens** — soft-delete sessions, cookie backup for tokens

### Changed
- Boot script Phase 1b for bridge creation
- Portal guards for bridge member VLANs
- Updater self-recovery via systemd-run

---

## v1.9.0 — Updater Self-Recovery + Change Password

**Release date:** August 2026

### Fixed
- **Updater kills itself during install** — update script now runs in its own systemd transient unit (`systemd-run`), completely outside the API's cgroup. `systemctl stop aircoins-api` no longer kills the update process.
- **Services not restarting after update** — retry logic added for service restart, all services (aircoins-api, lighttpd, dnsmasq, hostapd) reliably restart
- **Staging directory visibility** — moved from /tmp (private namespace) to /opt/aircoins/updates/staging for cross-unit access

### Added
- **Change Password** — new card on Settings page to change admin password (current password verification, min 6 chars)

---

## v1.8.2 — UTF-8 BOM Fix

**Release date:** August 2026

### Fixed
- **Manifest parse error** — strip UTF-8 BOM from Supabase manifest.json before JSON decoding
- **Defensive BOM handling** — Go code now handles BOM-prefixed JSON gracefully

---

## v1.8.1 — Updater Download Fix

**Release date:** August 2026

### Fixed
- **Download 404 error** — trim trailing slashes from SUPABASE_URL, fix URL construction
- **SHA256 case mismatch** — case-insensitive hash comparison
- **Better error messages** — download errors now include response details
- **Debug logging** — logs exact URLs being fetched for troubleshooting

---

## v1.8.0 — Supabase Storage Updater

**Release date:** August 2026

### Added
- **Two-step update flow** — separate Download and Install buttons for safer updates
- **Progress bar** — visual status indicator during download and installation
- **Supabase Storage integration** — updater now uses Supabase Storage instead of GitHub Releases
- **publish-release.sh** — new script to upload releases to Supabase Storage bucket

### Changed
- **Updater backend** — refactored to fetch manifest.json from Supabase Storage (public bucket, no auth needed)
- **Install from local file** — PerformUpdate now installs from pre-downloaded tarball in /opt/aircoins/updates/
- **SHA256 verification** — downloaded tarballs are verified against manifest checksum
- **5-minute download timeout** — fixed 10-second timeout that was too short for large files

### Removed
- **GitHub Releases dependency** — no longer uses GitHub API for update checks
- **GITHUB_TOKEN** — deprecated in favor of Supabase Storage

---

## v1.7.0 — Portal & License UI Improvements

**Release date:** August 2026

### Added
- **License key display** — License page now shows the panel's license key

### Changed
- **Portal buttons** — Pause Time and Rates buttons now match Insert Coin button size with distinct colors

---

## v1.6.2 — Critical Updater Fix

**Release date:** August 2026

### Fixed
- **Updater destroying system** — replaced full install.sh with targeted file replacement
- **Preserves configs** — .env, database, systemd units untouched during update
- **Clean service restart** — stops API, copies files, starts all services in order

---

## v1.6.1 — Private Repo Support & Self-Recovery

**Release date:** August 2026

### Fixed
- **Updater 404 on private repos** — added GITHUB_TOKEN authentication via environment variable
- **System unreachable after update** — now restarts all critical services (lighttpd, dnsmasq, hostapd) after update completes
- **Self-recovery** — service status logged to /tmp/aircoins-update.log for debugging

---

## v1.6.0 — Faster Coin Detection

**Release date:** August 2026

### Fixed
- **Coin detection delay** — reduced polling interval for faster coin insertion detection on the portal page

---

## v1.5.0 — Updater Fix, Mobile UI & Privacy

**Release date:** August 2026

### Fixed
- **Updater "Failed to fetch" bug** — response now sent before install.sh runs, auto-answers prompts, ensures service restart
- **Admin panel mobile layout** — hamburger menu, slide-in sidebar, full-width cards, scrollable tables, proper touch targets

### Changed
- Removed "View on GitHub" links from updater page to keep repository private

---

## v1.4.0 — Changelog Display & Updater Improvements

**Release date:** August 2026

### Added
- **Changelog display** — Updater page now shows release notes even when the system is up to date
- **GitHub release link** — Direct link to view release on GitHub from the updater page

### Changed
- Improved updater UI consistency across update-available and up-to-date states

---

## v1.3.0 — One-Click Update & Version Display Fix

**Release date:** August 2026

### Added
- **Update Now button** — download and install the latest release directly from the admin panel with one click
- **Post-update changelog** — shows success card with new version after update completes

### Fixed
- **Double-v version display** — updater page now shows correct version format (v1.3.0 not vv1.3.0)
- **Shared fetch logic** — extracted `fetchLatest` method for reuse between check and update endpoints

---

## v1.2.0 — System Reboot & Update Checker

**Release date:** August 2026

### Added
- **Reboot button** on the System page — allows admin to remotely reboot the SBC with confirmation dialog and auto-reconnect after 60 seconds
- **Update checker** (`/api/admin/updater/check`) — Admin sidebar page that checks GitHub for new releases, shows version comparison, changelog, and links to the release download

---

## v1.1.0

**Release date:** August 2026

### Added

- **Update checker** (`/api/admin/updater/check`) — Admin endpoint that queries the latest AirCoins release from GitHub and reports whether an update is available. Results are cached for 1 hour to avoid hammering the GitHub API. Supports `?force=true` to bypass the cache.

---

## v1.0.0 — First Production Release

**Release date:** August 2026  
**Target hardware:** Orange Pi PC (1GB RAM), Orange Pi One (512MB RAM)  
**Architecture:** Allwinner H3, ARMv7 (linux/arm/7)

---

### Features

- **Captive Portal** — Customer-facing WiFi portal with customizable appearance, per-VLAN splash pages, and multi-device captive detection (iOS, Android, Windows, macOS, Linux)
- **Admin Dashboard** — Single-page admin panel with real-time monitoring, session management, pricing configuration, GPIO pin control, VLAN management, and system statistics
- **License Management** — Supabase-backed licensing system with 7-day free trial from first boot, 24-hour heartbeat verification, CPU hardware ID binding, and automatic lockdown when license is invalid or expired
- **VLAN Support** — 802.1Q VLAN provisioning for network segmentation, per-VLAN DHCP (dnsmasq), per-VLAN captive portal rules, and per-VLAN traffic shaping
- **GPIO Coin Acceptor** — Hardware coin pulse detection via Orange Pi GPIO pins with configurable pin mapping, pulse counting, and credit accumulation
- **Session Management** — Time-based WiFi sessions with automatic expiry, idle timeout, extend/renew support, and real-time bandwidth tracking (tc/htb traffic shaping)
- **Traffic Shaping** — Per-session upload/download bandwidth limits using Linux tc/htb with per-VLAN rate configuration
- **Reverse Proxy** — lighttpd reverse proxy routing `/api/*` to the Go backend, with captive portal detection for 12+ OS probe paths
- **Emergency Recovery** — `aircoins-recover.sh` script to strip VLANs and restore the main network interface when configuration changes break connectivity

### Supported Hardware

| Board | RAM | CPU | Status |
|-------|-----|-----|--------|
| Orange Pi PC | 1GB | Allwinner H3 (Cortex-A7) | Supported |
| Orange Pi One | 512MB | Allwinner H3 (Cortex-A7) | Supported |

### System Requirements

- **OS**: Armbian 23.x+ (Bookworm or Bullseye recommended)
- **RAM**: 512MB minimum (1GB recommended)
- **Storage**: 500MB free disk space
- **Network**: Ethernet with VLAN-capable switch (for multi-VLAN setups)
- **Internet**: Required for initial installation (apt packages) and Supabase license verification (after 7-day trial)

### Quick Start

1. **Extract the release tarball:**
   ```bash
   tar xzf aircoins-v1.0.0.tar.gz
   cd aircoins-v1.0.0
   ```

2. **Run the installer:**
   ```bash
   sudo bash install.sh
   ```

3. **Configure Supabase licensing (optional for first 7 days):**
   ```bash
   sudo cp /opt/aircoins/.env.example /opt/aircoins/.env
   sudo nano /opt/aircoins/.env
   # Fill in your Supabase URL, anon key, and service role key
   sudo systemctl restart aircoins-api
   ```

4. **Reboot:**
   ```bash
   sudo reboot
   ```

5. **Access the admin panel:**
   Navigate to `http://<device-ip>/admin.html`

### Default Credentials

| Field | Value |
|-------|-------|
| Username | `admin` |
| Password | `admin123` |

> **Change the default password immediately after first login.**

### Supabase Setup (License System)

The license system requires a Supabase project. During the 7-day trial, no Supabase configuration is needed.

1. Create a project at [supabase.com](https://supabase.com)
2. Open the SQL Editor and run the contents of `system/database/supabase_aircoins_licenses.sql`
3. Copy your project credentials:
   - Project URL (Settings → API)
   - Anon public key (Settings → API)
   - Service role key (Settings → API → Show service role key)
4. Configure on the device:
   ```bash
   sudo cp /opt/aircoins/.env.example /opt/aircoins/.env
   sudo nano /opt/aircoins/.env
   ```
5. Restart the API:
   ```bash
   sudo systemctl restart aircoins-api
   ```

### Recovery

If network configuration changes break connectivity:
```bash
sudo bash /opt/aircoins/aircoins-recover.sh
```
This strips all VLAN sub-interfaces and restores the main physical interface IP.

### Known Limitations

- **Fresh install only** — No built-in upgrade path from previous versions. Back up configurations before upgrading.
- **Network interface naming** — Armbian may name the Ethernet interface `end0` instead of `eth0`. Check with `ip route show default` and edit `/etc/pisowifi/pisowifi.conf` if needed.
- **WiringOP GPIO** — The GPIO coin listener requires WiringOP, which may need build tools (`gcc`, `make`) not included in the default install.
- **Single WAN interface** — The system expects one upstream WAN connection for internet sharing.

### What's in the Tarball

```
aircoins-v1.0.0/
├── install.sh              # Automated installer
├── aircoins-recover.sh     # Emergency network recovery
├── .env.example            # Supabase credentials template
├── index.html              # Customer captive portal
├── admin.html              # Admin dashboard
├── DEPLOYMENT.md           # Full deployment guide
├── CHANGELOG.md            # This file
└── system/
    ├── database/           # PostgreSQL schema + migrations
    ├── etc/                # Config files + systemd units
    └── usr/                # API binary + shell scripts + CGI
```

### Verify Integrity

```bash
sha256sum -c aircoins-v1.0.0.sha256
```
